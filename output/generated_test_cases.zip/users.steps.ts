import { Given, When, Then } from '@cucumber/cucumber';
import { expect, request } from '@playwright/test';

let apiEndpoint: string;

Given('the API endpoint is {string}', (endpoint: string) => {
  apiEndpoint = endpoint;
});

When('I send a GET request to the API', async () => {
  const response = await request.get(apiEndpoint);
  return response;
});

Then('the response status code should be {int}', (statusCode: number) => {
  expect((await request.get(apiEndpoint)).status()).toBe(statusCode);
});

Then('the response body should contain a list of users', async () => {
  const response = await request.get(apiEndpoint);
  expect(response.json().data).toBeInstanceOf(Array);
});
